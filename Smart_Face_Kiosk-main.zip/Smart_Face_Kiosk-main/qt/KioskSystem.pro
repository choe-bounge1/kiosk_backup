TEMPLATE = subdirs
SUBDIRS = client
